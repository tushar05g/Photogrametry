"""
COLMAP Step - Structure from Motion with proper camera models
"""

import os
import subprocess
import logging

logger = logging.getLogger(__name__)

class ColmapStep:
    def execute(self, images_dir, workspace):
        """Run COLMAP with PINHOLE cameras for compatibility."""
        db_path = os.path.join(workspace, "database.db")
        sparse_dir = os.path.join(workspace, "sparse")
        os.makedirs(sparse_dir, exist_ok=True)
        
        xvfb = ["xvfb-run", "-a"]
        
        try:
            logger.info("Extracting features...")
            subprocess.run(xvfb + [
                "colmap", "feature_extractor",
                "--database_path", db_path,
                "--image_path", images_dir,
                "--SiftExtraction.use_gpu", "1",
                "--ImageReader.camera_model", "PINHOLE",
                "--ImageReader.single_camera", "1"
            ], check=True)

            logger.info("Matching features...")
            subprocess.run(xvfb + [
                "colmap", "exhaustive_matcher",
                "--database_path", db_path,
                "--SiftMatching.use_gpu", "1",
                "--SiftMatching.guided_matching", "1"
            ], check=True)

            logger.info("Mapping sparse cloud...")
            subprocess.run(xvfb + [
                "colmap", "mapper",
                "--database_path", db_path,
                "--image_path", images_dir,
                "--output_path", sparse_dir,
                "--Mapper.init_min_num_inliers", "4",
                "--Mapper.abs_pose_min_num_inliers", "4",
                "--Mapper.init_min_tri_angle", "2",
                "--Mapper.ba_global_images_ratio", "1.5",
                "--Mapper.min_model_size", "2",
                "--Mapper.init_max_error", "8.0",
                "--Mapper.abs_pose_max_error", "20.0"
            ], check=True)

            # --- ROBUST CHECK ---
            model_0 = os.path.join(sparse_dir, "0")
            if not os.path.exists(model_0):
                logger.error("COLMAP Mapper finished but no model (sparse/0) was produced.")
                # List files in sparse_dir to see what happened
                if os.path.exists(sparse_dir):
                    logger.info(f"Sparse dir contents: {os.listdir(sparse_dir)}")
                raise RuntimeError("COLMAP failed to reconstruct any model from these images.")

            # Create undistorted output for Gaussian Splatting
            undistorted_dir = os.path.join(workspace, "undistorted")
            os.makedirs(undistorted_dir, exist_ok=True)
            
            logger.info("Creating undistorted images...")
            subprocess.run(xvfb + [
                "colmap", "image_undistorter",
                "--image_path", images_dir,
                "--input_path", model_0,
                "--output_path", undistorted_dir,
                "--output_type", "COLMAP"
            ], check=True)

            return undistorted_dir
            
        except Exception as e:
            logger.error(f"COLMAP failed: {e}")
            raise

"""
Masking Step - Simple image download
"""

import os
import requests
import logging

logger = logging.getLogger(__name__)

class MaskingStep:
    def execute(self, images, output_folder):
        """Download images to local folder."""
        os.makedirs(output_folder, exist_ok=True)
        
        for i, url in enumerate(images):
            try:
                img_data = requests.get(url, timeout=30).content
                path = os.path.join(output_folder, f"img_{i:04d}.jpg")
                with open(path, "wb") as f:
                    f.write(img_data)
                logger.info(f"Downloaded image {i+1}/{len(images)}")
            except Exception as e:
                logger.error(f"Failed image {i}: {e}")
                raise
        
        return output_folder

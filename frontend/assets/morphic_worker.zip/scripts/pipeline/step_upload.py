"""
Upload Step - Upload GLB to Cloudinary
"""

import os
import cloudinary
import logging

logger = logging.getLogger(__name__)

class UploadStep:
    def execute(self, glb_path):
        """Upload GLB file to Cloudinary."""
        if not os.path.exists(glb_path):
            raise FileNotFoundError(f"GLB file not found: {glb_path}")
        
        try:
            logger.info(f"Uploading {os.path.basename(glb_path)}...")
            
            response = cloudinary.uploader.upload(
                glb_path,
                resource_type="raw",
                folder="3d_models"
            )
            
            return response["secure_url"]
            
        except Exception as e:
            logger.error(f"Upload failed: {e}")
            raise
